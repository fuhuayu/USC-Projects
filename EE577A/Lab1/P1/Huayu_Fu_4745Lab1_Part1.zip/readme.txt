Put the in.txt and lab1part1.py in same folder.
run the lab1part1.py it will generate 3 out files.
