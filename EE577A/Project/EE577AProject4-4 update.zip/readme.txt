You may start the simulation from the .vec files the folders contains.
Import the file into excel and change the values or use python to generate codes.
if you want to test each stage, it is better to have each stage with the registerd input and registerd output.
write more cmd to test the functionality correctiness of the schematic.